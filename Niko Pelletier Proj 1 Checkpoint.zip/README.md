Sources used:
- Beej's guide for help implementing initial server and client framework
- ZXing for QR codes