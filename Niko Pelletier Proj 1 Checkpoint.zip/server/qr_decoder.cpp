#include <iostream>
#include <string>
#include "qr_decoder.hpp"

std::string decode_qr(std::string filename){
    //TODO

    // std::string cmd = "java -cp javase.jar:core.jar com.google.zxing.client.j2se.CommandLineRunner " + qr;
    
    // char buf[128];
    // std::string output = "";
}