#ifndef QR_DECODER
#define QR_DECODER
#include <string>

std::string decode_qr(std::string filename);

#endif