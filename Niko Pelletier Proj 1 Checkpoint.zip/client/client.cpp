#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netdb.h>
#include <iostream>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]){
    struct addrinfo hints; //contains information that is passed to getaddrinfo
    struct addrinfo *res; //holds the results of getaddrinfo
    int sock; //socket descriptor of the socket used to handle client-server interaction

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    if(getaddrinfo("127.0.0.1", "2012", &hints, &res) != 0){
        std::cout << "getaddrinfo failure";
        exit(1);
    }

    if((sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol)) < 0){
        std::cout << "socket failure";
        exit(1);
    }

    if(connect(sock, res->ai_addr, res->ai_addrlen)){
        std::cout << "connect failure";
        exit(1);
    }

    //Communicating on socket sock

    FILE *msg = fopen("qr_testing/project1_qr_code.png", "rb");
    
    //get size of file
    struct stat st;
    fstat(fileno(msg), &st);
    off_t size = st.st_size;
    std::cout << "size of file: " << size << std::endl;

    //read file into buffer
    char buf[size];
    fread(buf, size, 1, msg);

    //send buffer
    off_t bytes_sent = 0;
    while(bytes_sent < size){
        bytes_sent += send(sock, buf, size, 0);
    }

    std::cout << "bytes sent: " << bytes_sent << std::endl;

    close(sock);

    std::cout << "Sent message: " << msg << std::endl;

    fclose(msg);

    return 0;
}